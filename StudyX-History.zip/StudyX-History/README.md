# StudyX History — Lịch sử 12

Phiên bản tách file từ website ôn thi lịch sử gốc, giữ nguyên ngân hàng câu hỏi và đáp án.

## Cấu trúc
- `index.html`: giao diện và các vùng nội dung.
- `assets/css/style.css`: toàn bộ giao diện, màu sắc, responsive.
- `assets/js/app.js`: điều hướng, hiển thị bài học, luyện tập, tạo đề và chấm điểm.
- `data/history.json`: ngân hàng dữ liệu lịch sử.

## Dữ liệu hiện có
- 6 bài học
- 51 câu hỏi lý thuyết kèm đáp án
- 20 tư liệu lịch sử
- 80 nhận định Đúng/Sai, mỗi nhận định có đáp án và giải thích
- 107 câu trắc nghiệm có đáp án
- 3 đề cố định và 1 đề ngẫu nhiên

## Chạy thử
Không nên mở `index.html` trực tiếp bằng `file://` vì trình duyệt chặn `fetch()` dữ liệu JSON.
Có thể:
1. Đưa toàn bộ thư mục lên GitHub repository.
2. Vào Settings → Pages.
3. Chọn Deploy from a branch → `main` → `/ (root)`.
4. Lưu và mở URL GitHub Pages.

Hoặc chạy bằng máy chủ tĩnh cục bộ.

## Ghi chú
Đây là bản frontend tĩnh. Dữ liệu câu hỏi nằm trong JSON công khai, phù hợp để ôn tập.
Tài khoản đồng bộ nhiều thiết bị, đăng ký/đăng nhập thật và phân quyền an toàn cần backend riêng
(ví dụ Supabase Auth + PostgreSQL + Row Level Security), không thể bảo mật chỉ bằng GitHub Pages.
