(async function(){
(async function(){
"use strict";
var DATA = await fetch('./data/history.json').then(function(r){if(!r.ok) throw new Error('Không tải được ngân hàng câu hỏi lịch sử');return r.json();});
var LESSONS = DATA.lessons;
var EXAMS = DATA.exams;

/* ---------- small utils ---------- */
function $(sel,root){return (root||document).querySelector(sel);}
function $all(sel,root){return Array.prototype.slice.call((root||document).querySelectorAll(sel));}
function el(tag,cls,html){var e=document.createElement(tag); if(cls)e.className=cls; if(html!==undefined)e.innerHTML=html; return e;}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
var LETTERS=['A','B','C','D'];

function mulberry32(seed){
  var t = seed>>>0;
  return function(){
    t += 0x6D2B79F5;
    var r = t;
    r = Math.imul(r ^ (r>>>15), r | 1);
    r ^= r + Math.imul(r ^ (r>>>7), r | 61);
    return ((r ^ (r>>>14))>>>0) / 4294967296;
  };
}
function seededShuffle(arr, seed){
  var rng = mulberry32(seed);
  var a = arr.slice();
  for(var i=a.length-1;i>0;i--){
    var j = Math.floor(rng()*(i+1));
    var tmp=a[i]; a[i]=a[j]; a[j]=tmp;
  }
  return a;
}

try{ var savedTheme = localStorage.getItem('ls12_theme'); if(savedTheme) document.documentElement.setAttribute('data-theme', savedTheme); }catch(e){}

/* ---------- flat pools for exam building ---------- */
var MCQ_POOL = [];
LESSONS.forEach(function(lesson, li){
  lesson.mcq.forEach(function(q){
    MCQ_POOL.push({lessonIdx:li, lessonTitle:lesson.title, q:q[0], opts:q[1], correct:q[2]});
  });
});
var TF_POOL = [];
LESSONS.forEach(function(lesson, li){
  lesson.docs.forEach(function(doc){
    TF_POOL.push({lessonIdx:li, lessonTitle:lesson.title, src:doc.src, cite:doc.cite, tf:doc.tf});
  });
});

/* ======================= ROUTER ======================= */
var topTabs = $all('.tab-btn');
var views = {
  lessons: $('#view-lessons'),
  'lesson-detail': $('#view-lesson-detail'),
  exams: $('#view-exams'),
  'exam-take': $('#view-exam-take')
};
function showView(name){
  Object.keys(views).forEach(function(k){ views[k].hidden = (k!==name); });
  var topLevel = (name==='lessons'||name==='lesson-detail') ? 'lessons' : 'exams';
  topTabs.forEach(function(b){ b.classList.toggle('active', b.dataset.tab===topLevel); });
  window.scrollTo({top:0, behavior:'instant' in window ? 'instant':'auto'});
}
topTabs.forEach(function(b){
  b.addEventListener('click', function(){ showView(b.dataset.tab); });
});
$all('[data-back]').forEach(function(b){
  b.addEventListener('click', function(){ showView(b.dataset.back); });
});

/* ======================= LESSON LIST ======================= */
function renderLessonList(){
  var grid = $('#lessonGrid'); grid.innerHTML='';
  LESSONS.forEach(function(lesson, idx){
    var tfCount = lesson.docs.reduce(function(s,d){return s+d.tf.length;},0);
    var card = el('button','lesson-card');
    card.innerHTML =
      '<span class="lesson-num">BÀI '+(idx+1)+'</span>'+
      '<h3>'+esc(lesson.title.replace(/^Bài \d+\.\s*/,''))+'</h3>'+
      '<div class="lesson-stats">'+
        '<span class="stat-chip">'+lesson.qa.length+' câu hỏi lý thuyết</span>'+
        '<span class="stat-chip">'+lesson.docs.length+' tư liệu</span>'+
        '<span class="stat-chip">'+lesson.mcq.length+' câu TN</span>'+
        '<span class="stat-chip">'+tfCount+' ý Đúng/Sai</span>'+
      '</div>';
    card.addEventListener('click', function(){ openLesson(idx); });
    grid.appendChild(card);
  });
}

/* ======================= LESSON DETAIL ======================= */
var currentLesson = null;
function openLesson(idx){
  currentLesson = idx;
  var lesson = LESSONS[idx];
  $('#ldEyebrow').textContent = 'Bài '+(idx+1)+' / '+LESSONS.length;
  $('#ldTitle').textContent = lesson.title;
  renderQA(lesson);
  renderDocs(lesson);
  renderLessonMCQ(lesson);
  $all('.block-nav button').forEach(function(b,i){ b.classList.toggle('active', i===0); });
  $('#ldQA').hidden=false; $('#ldDoc').hidden=true; $('#ldMCQ').hidden=true;
  showView('lesson-detail');
}
$all('.block-nav button').forEach(function(btn){
  btn.addEventListener('click', function(){
    $all('.block-nav button').forEach(function(b){b.classList.remove('active');});
    btn.classList.add('active');
    $('#ldQA').hidden = btn.dataset.block!=='qa';
    $('#ldDoc').hidden = btn.dataset.block!=='doc';
    $('#ldMCQ').hidden = btn.dataset.block!=='mcq';
  });
});

function renderQA(lesson){
  var host = $('#ldQA'); host.innerHTML='';
  lesson.qa.forEach(function(pair, i){
    var item = el('div','qa-item');
    item.innerHTML =
      '<button class="qa-q"><span class="idx">Câu '+(i+1)+'.</span><span>'+esc(pair[0])+'</span>'+
      '<span class="chev">▾</span></button>'+
      '<div class="qa-a"><div class="qa-a-inner">'+esc(pair[1])+'</div></div>';
    $('.qa-q',item).addEventListener('click', function(){ item.classList.toggle('open'); });
    host.appendChild(item);
  });
}

function renderDocs(lesson){
  var host = $('#ldDoc'); host.innerHTML='';
  lesson.docs.forEach(function(doc, di){
    var card = el('div','doc-card');
    var html = '<div class="doc-src">“'+esc(doc.src).replace(/^“|”$/g,'')+'”</div>'+
      '<div class="doc-cite">'+esc(doc.cite)+'</div>'+
      '<div class="tf-list"></div>'+
      '<div class="tf-tally"></div>';
    card.innerHTML = html;
    var list = $('.tf-list',card);
    var tally = $('.tf-tally',card);
    var states = doc.tf.map(function(){return null;});
    doc.tf.forEach(function(stmt, si){
      var row = el('div','tf-row');
      row.innerHTML =
        '<div class="stmt"><span class="lab">'+String.fromCharCode(97+si)+')</span><span>'+esc(stmt[0])+'</span></div>'+
        '<div class="tf-toggle">'+
          '<button class="tf-btn" data-v="true">Đúng</button>'+
          '<button class="tf-btn" data-v="false">Sai</button>'+
        '</div>'+
        '<div class="tf-explain">'+esc(stmt[2])+'</div>';
      $all('.tf-btn',row).forEach(function(btn){
        btn.addEventListener('click', function(){
          if(row.classList.contains('answered')) return;
          var val = btn.dataset.v==='true';
          states[si] = val;
          row.classList.add('answered');
          $all('.tf-btn',row).forEach(function(b2){
            var bv = b2.dataset.v==='true';
            if(bv===stmt[1]) b2.classList.add('correct');
            else if(bv===val) b2.classList.add('incorrect');
          });
          if(states.every(function(s){return s!==null;})){
            var correctCount = states.filter(function(s,k){return s===doc.tf[k][1];}).length;
            var pts = [0,0.1,0.25,0.5,1][correctCount];
            tally.textContent = 'Nếu đây là câu hỏi trong đề thi: '+correctCount+'/4 ý đúng → '+pts.toString().replace('.',',')+'đ / 1đ';
            tally.classList.add('show');
          }
        });
      });
      list.appendChild(row);
    });
    host.appendChild(card);
  });
}

function renderLessonMCQ(lesson){
  var host = $('#ldMCQ'); host.innerHTML='';
  var toolbar = el('div','toolbar-row');
  toolbar.innerHTML = '<span class="sub">'+lesson.mcq.length+' câu — bấm vào một phương án để xem ngay kết quả.</span>'+
    '<button class="btn btn-ghost btn-sm" id="shuffleMcq">🔀 Xáo câu &amp; làm lại</button>';
  host.appendChild(toolbar);
  var list = el('div','panel'); host.appendChild(list);

  function draw(order){
    list.innerHTML='';
    order.forEach(function(qi, i){
      var q = lesson.mcq[qi];
      var card = el('div','mcq-card');
      card.innerHTML = '<div class="mcq-q"><span class="idx">Câu '+(i+1)+'.</span><span>'+esc(q[0])+'</span></div>'+
        '<div class="mcq-opts"></div>';
      var optsHost = $('.mcq-opts',card);
      q[1].forEach(function(opt, oi){
        var b = el('button','opt-btn');
        b.innerHTML = '<span class="lab">'+LETTERS[oi]+'.</span><span>'+esc(opt)+'</span>';
        b.addEventListener('click', function(){
          $all('.opt-btn',card).forEach(function(o,k){
            o.classList.add('locked');
            if(k===q[2]) o.classList.add('correct');
          });
          if(oi!==q[2]) b.classList.add('incorrect');
        });
        optsHost.appendChild(b);
      });
      list.appendChild(card);
    });
  }
  var order = lesson.mcq.map(function(_,i){return i;});
  draw(order);
  $('#shuffleMcq').addEventListener('click', function(){
    order = seededShuffle(order, Date.now()%2147483647);
    draw(order);
  });
}

/* ======================= EXAM LIST ======================= */
function renderExamList(){
  var grid = $('#examGrid'); grid.innerHTML='';
  EXAMS.forEach(function(exam){
    var isRandom = exam.seed===null;
    var card = el('div','exam-card'+(isRandom?' random':''));
    card.innerHTML =
      '<span class="exam-tag">'+(isRandom?'Ngẫu nhiên mỗi lượt':'Đề cố định')+'</span>'+
      '<h3>'+esc(exam.name)+'</h3>'+
      '<div class="exam-meta">24 câu trắc nghiệm + 4 câu Đúng/Sai<br>Thang điểm <b>10</b> · chấm theo BGD&amp;ĐT</div>'+
      '<button class="btn btn-primary">Bắt đầu làm bài</button>';
    $('button',card).addEventListener('click', function(){ startExam(exam); });
    grid.appendChild(card);
  });
}

/* ======================= EXAM TAKE ======================= */
var activeExam = null; // {name, mcq:[...24], tf:[...4 groups]}
var examAnswers = null;
var examSubmitted = false;

function buildExam(exam){
  var seed = exam.seed===null ? (Date.now()%2147483647) : exam.seed;
  var mcqShuf = seededShuffle(MCQ_POOL, seed);
  var tfShuf = seededShuffle(TF_POOL, seed+777);
  return {
    name: exam.name,
    mcq: mcqShuf.slice(0,24),
    tf: tfShuf.slice(0,4)
  };
}

function startExam(exam){
  activeExam = buildExam(exam);
  examAnswers = {
    mcq: activeExam.mcq.map(function(){return null;}),
    tf: activeExam.tf.map(function(g){return g.tf.map(function(){return null;});})
  };
  examSubmitted = false;
  $('#examTakeTitle').textContent = exam.name;
  $('#resultZone').hidden = true;
  $('#resultZone').innerHTML='';
  $('#btnSubmit').hidden = false;
  $('#btnRetry').hidden = true;
  renderExamQuestions();
  updateSubmitStat();
  showView('exam-take');
}

function renderExamQuestions(){
  var mcqHost = $('#examMCQList'); mcqHost.innerHTML='';
  activeExam.mcq.forEach(function(q, qi){
    var card = el('div','mcq-card');
    card.id = 'examMcq-'+qi;
    card.innerHTML = '<div class="mcq-q"><span class="idx">Câu '+(qi+1)+'.</span><span>'+esc(q.q)+'<span class="q-flag" style="display:none"></span></span></div>'+
      '<div class="mcq-opts"></div>';
    var optsHost = $('.mcq-opts',card);
    q.opts.forEach(function(opt, oi){
      var b = el('button','opt-btn');
      b.innerHTML = '<span class="lab">'+LETTERS[oi]+'.</span><span>'+esc(opt)+'</span>';
      b.addEventListener('click', function(){
        if(examSubmitted) return;
        examAnswers.mcq[qi]=oi;
        $all('.opt-btn',card).forEach(function(o){o.classList.remove('sel-true');});
        b.classList.add('sel-true');
        updateSubmitStat();
      });
      optsHost.appendChild(b);
    });
    mcqHost.appendChild(card);
  });

  var tfHost = $('#examTFList'); tfHost.innerHTML='';
  activeExam.tf.forEach(function(group, gi){
    var card = el('div','tf-exam-group');
    card.id = 'examTf-'+gi;
    var html = '<div class="grp-title">Câu '+(gi+1)+'<span class="q-flag" style="display:none"></span></div>'+
      '<div class="doc-src">“'+esc(group.src).replace(/^“|”$/g,'')+'”</div>'+
      '<div class="doc-cite">'+esc(group.cite)+'</div>'+
      '<div class="tf-list"></div>';
    card.innerHTML = html;
    var list = $('.tf-list',card);
    group.tf.forEach(function(stmt, si){
      var row = el('div','tf-row');
      row.innerHTML =
        '<div class="stmt"><span class="lab">'+String.fromCharCode(97+si)+')</span><span>'+esc(stmt[0])+'</span></div>'+
        '<div class="tf-toggle">'+
          '<button class="tf-btn" data-v="true">Đúng</button>'+
          '<button class="tf-btn" data-v="false">Sai</button>'+
        '</div>'+
        '<div class="tf-explain">'+esc(stmt[2])+'</div>';
      $all('.tf-btn',row).forEach(function(btn){
        btn.addEventListener('click', function(){
          if(examSubmitted) return;
          var val = btn.dataset.v==='true';
          examAnswers.tf[gi][si]=val;
          $all('.tf-btn',row).forEach(function(b2){ b2.classList.toggle('sel-true', (b2.dataset.v==='true')===val); });
          updateSubmitStat();
        });
      });
      list.appendChild(row);
    });
    tfHost.appendChild(card);
  });
}

function countAnswered(){
  var n = examAnswers.mcq.filter(function(v){return v!==null;}).length;
  examAnswers.tf.forEach(function(g){ n += g.filter(function(v){return v!==null;}).length; });
  return n;
}
function updateSubmitStat(){
  var total = 24 + 4*4;
  var done = countAnswered();
  $('#submitStat').innerHTML = 'Đã trả lời <b class="tabular">'+done+'</b>/'+total+' câu';
  var pct = Math.round((done/total)*100);
  $('#examProgress').style.width = pct+'%';
}

$('#btnSubmit').addEventListener('click', function(){
  if(examSubmitted) return;
  examSubmitted = true;
  gradeExam();
  $('#btnSubmit').hidden = true;
  $('#btnRetry').hidden = false;
});
$('#btnRetry').addEventListener('click', function(){
  var exam = EXAMS.find(function(e){return e.name===activeExam.name;});
  startExam(exam);
});

function gradeExam(){
  var mcqCorrect = 0;
  activeExam.mcq.forEach(function(q, qi){
    var chosen = examAnswers.mcq[qi];
    var card = $('#examMcq-'+qi);
    var flag = $('.q-flag',card); flag.style.display='inline-block';
    $all('.opt-btn',card).forEach(function(o,oi){
      o.classList.add('locked');
      if(oi===q.correct) o.classList.add('correct');
      else if(oi===chosen) o.classList.add('incorrect');
    });
    if(chosen===q.correct){ mcqCorrect++; flag.textContent='Đúng'; flag.className='q-flag correct'; }
    else { flag.textContent='Sai'; flag.className='q-flag incorrect'; }
  });
  var mcqScore = mcqCorrect*0.25;

  var tfScore = 0;
  var tfCorrectTotal = 0, tfTotalStmt = 0;
  activeExam.tf.forEach(function(group, gi){
    var card = $('#examTf-'+gi);
    var flag = $('.q-flag',card); flag.style.display='inline-block';
    var rows = $all('.tf-row',card);
    var correctCount = 0;
    group.tf.forEach(function(stmt, si){
      tfTotalStmt++;
      var row = rows[si];
      var chosen = examAnswers.tf[gi][si];
      $all('.tf-btn',row).forEach(function(b2){
        var bv = b2.dataset.v==='true';
        if(bv===stmt[1]) b2.classList.add('correct');
        else if(bv===chosen) b2.classList.add('incorrect');
      });
      row.classList.add('answered');
      if(chosen===stmt[1]){ correctCount++; tfCorrectTotal++; }
    });
    var pts = [0,0.1,0.25,0.5,1][correctCount];
    tfScore += pts;
    flag.textContent = correctCount+'/4 ý · '+pts.toString().replace('.',',')+'đ';
    flag.className = 'q-flag '+(correctCount===4?'correct':(correctCount===0?'incorrect':'partial'));
  });

  var total = Math.round((mcqScore+tfScore)*100)/100;
  var zone = $('#resultZone');
  zone.hidden = false;
  zone.innerHTML =
    '<div class="result-card">'+
      '<div class="result-score tabular">'+total.toString().replace('.',',')+'<span>/10</span></div>'+
      '<div class="result-sub">'+activeExam.name+' · '+mcqCorrect+'/24 câu TN đúng · '+tfCorrectTotal+'/'+tfTotalStmt+' ý Đúng/Sai đúng</div>'+
      '<div class="result-breakdown">'+
        '<div class="rb-chip"><b class="tabular">'+mcqScore.toString().replace('.',',')+'đ</b>Phần I (6đ)</div>'+
        '<div class="rb-chip"><b class="tabular">'+tfScore.toString().replace('.',',')+'đ</b>Phần II (4đ)</div>'+
      '</div>'+
    '</div>';
  zone.scrollIntoView({behavior:'smooth', block:'start'});
}

/* ======================= INIT ======================= */
renderLessonList();
renderExamList();
showView('lessons');
})();
})().catch(function(error){console.error(error);document.body.insertAdjacentHTML('afterbegin','<div style="padding:16px;background:#fbe9e5;color:#8b2118">Không thể tải dữ liệu StudyX History. Hãy chạy website qua GitHub Pages hoặc máy chủ HTTP.</div>');});
